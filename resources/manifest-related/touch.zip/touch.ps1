﻿"
CSI-Windows.com: Be The Expert, Get Apps Running On Anything.
More tools at CSI-Windows.com/toolkit

" + $myinvocation.mycommand.name + " sets file modified date and time to the current 
time for one or more files specified on the command line.
"
If ($args.count -eq 0) {
  "Please provide filename(s) to touch."
  } else {
  $CurrentDate = Get-Date
  $args | foreach { Set-ItemProperty $_ LastWriteTime ($CurrentDate)
  "  " + $_ + " Modified Date set to " + $CurrentDate}
  "
  Done."
  }

